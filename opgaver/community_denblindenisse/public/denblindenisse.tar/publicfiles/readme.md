### README
To run the server locally, we recommend using the provided dockerfile. 
To build, use the command `docker build -t signer ./` in the folder.
To run, use use the command `docker run --name signer signer`to run the server, listening on localhost on port 4343. 
You can now communicate with it using nc, or through python using pwntools/telnet. The server receives and sends JSON, which can easily be converted to/from python dictionaries using `json.dumps()` and `json.load()`.

The real flag is only on our server, however we strongly recommend developing your exploit locally before running against the remote server.

The goal is to receive up to 300 blind signatures, then provide the server 301 valid signatures on different messages to receive the flag. On connecting to the server you provide an ID, with each ID corresponding to a session with a unique key, and a counter of how many signatures under that key the server has created. You should choose a unique random ID for each solve attempt, (fx, `random.randint(2,2**32)`).

Note: The remote server may be restarted periodically, so old sessions might eventually be deleted.

The library we used for the Abe-Okamoto Signature scheme [https://www.iacr.org/archive/crypto2000/18800272/18800272.pdf] can be found here https://github.com/rot256/pblind

Note: The intended solution does not involve any implementation bugs or vulnerabilities in the pblind package. If you find an unintended implementation vulnerability in the package which lets you solve the challenge, please let us know at nc3.ctf.2021@kalmarunionen.dk!

Glædelig Jul!

- Killerdog, rot256