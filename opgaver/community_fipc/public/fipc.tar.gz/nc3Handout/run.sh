#!/bin/sh

/usr/bin/qemu-system-x86_64 -kernel bzImage -initrd init.cpio -nographic -cpu qemu64,+smep,+smap,+rdrand -append "console=ttyS0 quiet"
